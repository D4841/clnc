#!/system/bin/sh

id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh


find /data/user/*/com.UCMobile /data/data/com.UCMobile /data/media/*/Android/data/com.UCMobile -iname "tt_mediation_open_sdk.db" -type f -o -iname "GDTDOWNLOAD" -type d -o -iname "tad_cache" -type d -o -iname "app_ad" -type d -o -iname "TTCache" -type d -o -iname "app_ad" -type d -o -iname "cachett_ad" -type d -o -iname "splash_image" -type d -o -iname "tt_tmpl_pkg" -type d -o -iname "com_qq_e_download" -type d -o -iname "pangle_com.byted.pangle" -type d -o -iname "noah_ads" -type d -o -iname "pangle_p" -type d -o -iname "advertise" -type d 2>/dev/null | while read adfile ;do
	mkdir_file "${adfile}" 2>/dev/null 
done

