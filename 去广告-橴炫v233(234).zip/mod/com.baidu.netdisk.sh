
rm -rf /data/user/*/com.baidu.netdisk/files/*_*send_data*