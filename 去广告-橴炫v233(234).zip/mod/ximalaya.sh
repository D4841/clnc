#!/system/bin/sh

function deny_appops(){
local IFS=$'\n'
local package="$1"
local action="$2"
local list="
AUDIO_MEDIA_VOLUME
CHANGE_WIFI_STATE
FINE_LOCATION
LEGACY_STORAGE
MOCK_LOCATION
MONITOR_HIGH_POWER_LOCATION
MONITOR_LOCATION
READ_CALENDAR
READ_DEVICE_IDENTIFIERS
READ_PHONE_STATE
SYSTEM_ALERT_WINDOW
TOAST_WINDOW
VIBRATE
WAKE_LOCK
WRITE_CALENDAR
WRITE_EXTERNAL_STORAGE
"
for ops in $list 
do
	cmd appops set $package $ops $action
done
}

deny_appops "com.ximalaya.ting.android" "ignore"

