test ! -f "${0%/*}/a0.app.xiaomi.com.sh" && exit 0
source "${0%/*}/a0.app.xiaomi.com.sh"
#允许云备份
#Xiaomi_backup "allow"
#禁用云备份
Xiaomi_backup
