function deny_appops(){
local IFS=$'\n'
local package="$1"
local action="$2"
local list="
#振动权限
#VIBRATE
#写入日历
WRITE_CALENDAR
WRITE_EXTERNAL_STORAGE
#身体传感器
ACTIVITY_RECOGNITION
BODY_SENSORS
"
for ops in $list 
do
	echo "${ops}" | grep -q "^#" && continue
	cmd appops set $package $ops $action 
done
}

#百度网盘
deny_appops "com.baidu.netdisk" "ignore" >/dev/null 2>&1 
#贴吧
deny_appops "com.baidu.tieba" "ignore" >/dev/null 2>&1
#快手
deny_appops "com.smile.gifmaker" "ignore" >/dev/null 2>&1
